/**
 * Marlin 3D Printer Firmware
 * Copyright (c) 2020 MarlinFirmware [https://github.com/MarlinFirmware/Marlin]
 *
 * Based on Sprinter and grbl.
 * Copyright (c) 2011 Camiel Gubbels / Erik van der Zalm
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "../../../inc/MarlinConfig.h"

#if ENABLED(MIXING_EXTRUDER) && ENABLED(HOTEND_CLEAN_TOWER) && (MIXING_STEPPERS > 2)

#include "../../gcode.h"
#include "../../../feature/mixing.h"

/**
 * M168: print a clean tower when switch color
 *   P[x]   	Pattern, 0 or 1
 *   C[x]   	Total Used Colors, max = 16
 *   F[x]   	factor (=Used Nozzle_size/0.4)
 *   X[mm]   	Tower start position of X (mm)
 *   Y[mm]   	Tower start position of Y (mm)
 *   L[mm]   	length of tower (In the x-axis direction)
 *   E[mm]   	Extruder length, if extruded line length is over this value, it will auto exit printing the tower
 *   R[mm]   	Retraction length before go to tower and 
 *   A[mm/s]   	Retraction speed 
 *
 *   Note:
 *   If P=1, L must be equal to W and must be a multiple of nozzle size
 *
 *   e.g.: 
 *   1. M168 P0 C3 F1 X100 Y100 L30 E20 R12 A25
 *      generate a clean tower, start from {x, y}, and extruder will retract filament when start to print this tower and finish to print this tower
 *   2. M168 P1 C3 F1 X100 Y100 L30 E20 R12 A25      
 *      generate a clean tower, start from {x, y}, and extruder will retract filament when start to print this tower and finish to print this tower
 */

void GcodeSuite::M168() {  
  if (parser.seenval('P')) 	mixer.cleantower.pattern = parser.value_byte();
  
  if (parser.seenval('C')) 	mixer.cleantower.colors  = parser.value_byte();
  if (parser.seenval('F')) 	mixer.cleantower.factor = parser.value_float();
  
  if (parser.seenval('X')) 	mixer.cleantower.x = parser.value_int();
  if (parser.seenval('Y')) 	mixer.cleantower.y = parser.value_int();
  if (parser.seenval('L')) 	mixer.cleantower.length = parser.value_int();
  if (parser.seenval('W')) 	mixer.cleantower.flow_length = parser.value_byte();  
  
  if (parser.seenval('R')) 	mixer.cleantower.retraction_length = parser.value_float();
  if (parser.seenval('A')) 	mixer.cleantower.retraction_speed = parser.value_int();

  if(mixer.cleantower.pattern > 2)
  	return; 
  if((mixer.cleantower.colors < 2) || (mixer.cleantower.colors > 16))
  	return; 
  if((mixer.cleantower.x + mixer.cleantower.length > (X_BED_SIZE - 10)) || (mixer.cleantower.y > (Y_BED_SIZE - 10)))
  	return;   
  if(mixer.cleantower.length > (X_BED_SIZE - 30))
  	return; 
  if(mixer.cleantower.retraction_length > 30 || mixer.cleantower.retraction_speed > 45)
  	return;

  mixer.build_clean_tower();
}

#endif
